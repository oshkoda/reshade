#include "xess_dbg.h"

xess_result_t hk_xessSelectNetworkModel(xess_context_handle_t hContext, xess_network_model_t network)
{
    return XESS_RESULT_SUCCESS;
}

xess_result_t hk_xessStartDump(xess_context_handle_t hContext, const xess_dump_parameters_t* dump_parameters)
{
    return XESS_RESULT_SUCCESS;
}
