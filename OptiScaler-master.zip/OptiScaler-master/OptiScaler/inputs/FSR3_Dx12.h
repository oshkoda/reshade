#pragma once

#include "pch.h"

void HookFSR3ExeInputs();
void HookFSR3Inputs(HMODULE module);
void HookFSR3Dx12Inputs(HMODULE module);
