#pragma once

#include "pch.h"

void HookFSR2ExeInputs();
void HookFSR2Inputs(HMODULE module);
void HookFSR2Dx12Inputs(HMODULE module);
