#include "Config.h"
#include "Util.h"

#include "xess_debug.h"
#include "NVNGX_Parameter.h"

XESS_API xess_result_t xessSelectNetworkModel(xess_context_handle_t hContext, xess_network_model_t network)
{
    return XESS_RESULT_SUCCESS;
}

XESS_API xess_result_t xessStartDump(xess_context_handle_t hContext, const xess_dump_parameters_t* dump_parameters)
{
    return XESS_RESULT_SUCCESS;
}
