#pragma once
#include "pch.h"

void HookFfxExeInputs();
