#pragma once

#include "d3d12.h"
#include "dbghelp.h"
#include "dxgi.h"
#include "shared.h"
#include "version.h"
#include "winhttp.h"
#include "wininet.h"
#include "winmm.h"
